chmod +x build.sh # make the "build.sh" executabled
./build.sh # run "build.sh"
docker-compose up # run the "docker-compose.yml"